%% Files

1.data.do import rata data and generates data_final.dta
3.placebo1.do estimate the synthetic counterfactual and placebos using commodity republics as donor pool
3.placebo2.do estimate the synthetic counterfactual and placebos using OECD as donor pool
3.placebo3.do estimate the synthetic counterfactual and placebos using Latam as donor pool
3.placebo4.do estimate the in-time placebo with commodity republics as donor pool
4.plots replicates the plots included in the paper